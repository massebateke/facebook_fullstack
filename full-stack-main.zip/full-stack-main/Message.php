<?php
//ne pas oublier de vérifier token
require('config.php');

session_start();


if (isset($_GET['id']) AND !empty($_GET['id']))
{
    $getid =$_GET['id'];
    $recupUsers = $conn->prepare('SELECT * FROM profil WHERE user_id = ?');
    $recupUsers->execute(array($getid));
    if($recupUsers->rowCount() > 0){
        if(isset($_POST['envoyer'])){
            $message = htmlspecialchars($_POST['message']);
            $insererMessage = $conn->prepare('INSERT INTO messages_privees(user_id, destinataire_id, contenu) VALUES(?, ?, ?)');
            $insererMessage->execute(array($_SESSION['user_id'], $getid, $message));

        }
    }
    elseif(isset($_POST['supprimer'])){ // a replacer je crois qu'il est mal placé er qu'il reconnais pas
        $supprimerMessage = $conn->prepare('DELETE FROM messages_privees WHERE id = :id');
        $supprimerMessage->execute(["id" =>  $message['id']]);
        var_dump($supprimerMessage);
    }
    else{
        echo "Aucun utilisateur trouvé";
    }
}
else{
    echo "Aucun identifiant trouvé";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Message.css">
    <title>discussion privée</title>
</head>
<body>
<header class="header">
            <div class="container">
              <div class="header__logo">UNIBOOK</div>
              
                <form action="/recherche" method="get">
                <div class="recherche">
                  <input type="text" class="bar"name="query"  placeholder="Rechercher sur UNIBOOK">
                </div>
              </form>
              <nav class="header__nav">
                <ul>
                  <li><a href="#"><img src="./images/message.png" class="message"></a></li>
                  <li><a href="#"><img src="./images/logout.png" class="logout"></a></li>
                </ul>
              </nav>
            </div>
          </header>

    <form action="" method="post">
        <textarea class="Box-message" name="message" id="message" rows="10"></textarea>
        <br><br>
        <input type="submit" name="envoyer" value="Envoyer" class="Envoyer">
    </form>
    
    <section id="messages">
        <?php 
            $recupMessages = $conn->prepare('SELECT * FROM messages_privees WHERE user_id = ? AND destinataire_id = ? OR user_id = ? AND destinataire_id = ? ORDER BY date_creation DESC LIMIT 25'); 
            $recupMessages->execute(array($_SESSION['user_id'], $getid, $getid, $_SESSION['user_id'] ));
            while($message = $recupMessages->fetch()){
                if($message['user_id'] == $_SESSION['user_id']){
                    ?>
                        <p class="msg-envoyer"style="color:red;"><?=  $message['contenu']; ?></p>
                        <input class="msg-envoyer" type="submit" name="supprimer" value="Supprimer">
                        <input class="msg-envoyer" type="submit" name="modifier" value="Modifier">
                 <?php        
                }
                elseif($message['user_id'] ==$getid){
                    ?>
                    <p style="color:green;"><?=  $message['contenu']; ?></p>
             <?php      
                }
                ?>
                <?php 

            }
        ?>

    </section>

</body>
</html>