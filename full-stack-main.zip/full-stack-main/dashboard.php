<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="" href="../assets/styles/style2.css">
</head>
<body>
<img src="../assets/images/wallpaper.jpeg" alt="">

<div class="form">
<h1>Vous êtes connecté(e) !</h1>

<a href="logout.php"><div class="button">Déconnexion</div></a>
</div>
</body>
</html>